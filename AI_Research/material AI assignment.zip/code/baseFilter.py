from abc import ABC, abstractmethod

class baseFilter(ABC):
    @abstractmethod
    def train(self, trainingSet): pass

    @abstractmethod
    def classifyTweet(self, tweet): pass

    @abstractmethod
    def dumpFilter(self): pass

    @abstractmethod
    def loadFilter(self, savedFilter): pass
