from algorithms.filter.baseFilter import baseFilter


class wordFilter(baseFilter):
    """
    This class is an implementation of a word-frequency filter.
    """
    def __init__(self):
        self.words = None

    def train(self, tweets):
        """
        This function trains the filter to classify tweets as fake or true
        :param tweets: Dictionary of tweet, text and label as follows: {id: {text: "example text", "label":"0"}, id2:{}}
        :return: None. This function sets the internal wordDict to classify new tweets against
        """
        # Ratio used to decide the percentage of real vs fake tweets in training set
        ratio = {"0": 0, "1": 0}
        wordDict = dict()

        # Making a dictionary with absolute numbers of occurences
        for tweet in tweets:

            label = tweets[tweet]["label"]
            ratio[label] += 1
            for word in tweets[tweet]["text"].split(" "):
                word = word.lower()
                if word not in wordDict:
                    wordDict[word] = {'0': 0, '1': 0}
                wordDict[word][label] += 1

        # Afterwards, convert totals to percentages
        for word in wordDict:
            wordDict[word]['0'] = (wordDict[word]['0'] / ratio['0']) * 100
            wordDict[word]['1'] = (wordDict[word]['1'] / ratio['1']) * 100

        self.words = wordDict

    def findMostUsedWords(self):
        """
        This is a utility function to find the most decisive words
        :return: A dictionary with 2 keys ('1' and '0'), containing the words for each category with the greatest difference
        """
        if self.words is None:
            raise AttributeError("This filter hasn't been trained yet")

        greatestDifference = {'0': [], '1': []}
        for word, values in self.words.items():
            diff = values['0'] - values['1']
            wordObj = {'word': word, '0': values['0'], '1': values['1'], 'absdiff': abs(diff)}
            if diff < 0:
                greatestDifference['1'].append(wordObj)
            else:
                greatestDifference['0'].append(wordObj)

        greatestDifference['0'] = sorted(greatestDifference['0'], key=lambda i: i['absdiff'], reverse=True)
        greatestDifference['1'] = sorted(greatestDifference['1'], key=lambda i: i['absdiff'], reverse=True)

        return greatestDifference

    def classifyTweet(self, tweet):
        """
        Classifies a tweet based on the word frequency used, compared to the trained filter
        :param tweet: The text of a tweet, as a string
        :return: A float between 0 and 1, 0 being fake and 1 being real
        """
        fakeTotal = 0
        trueTotal = 0
        for word in tweet.split(' '):
            word = word.lower()
            if word in self.words:
                fakeTotal += self.words[word]['0']
                trueTotal += self.words[word]['1']

        if fakeTotal == 0 and trueTotal == 0:
            return 0
        return (trueTotal / (fakeTotal + trueTotal))

    def dumpFilter(self):
        return self.words

    def loadFilter(self, savedFilter):
        self.words = savedFilter
        return None
