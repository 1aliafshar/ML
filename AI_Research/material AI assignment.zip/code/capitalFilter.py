from algorithms.filter.baseFilter import baseFilter


class capitalFilter(baseFilter):
    """
    This class is an implementation of the capital filter, which focuses on the capital casing in a tweet.
    """
    def train(self, trainingSet):
        """
        This is an inherited function, but this filter doesn't need to train on a dataset. As such, it simply passes.
        :param trainingSet: The set of trainingdata
        :return: None.
        """
        return None

    def testCapitals(self, tweets):
        """
        This function validates the filter against a set of tweets.
        :param tweets: Validation set of tweets
        :return: dictionary of succesfull guesses and failed guesses.
        """
        countDict = {"Correct": 0, "false": 0}
        for tweet in tweets:
            c = self.classifyTweet(tweets[tweet]['text'])

            correct = 1
            if c == None or c < .2:
                correct = 0

            if correct == int(tweets[tweet]['label']):
                countDict['Correct'] += 1
            else:
                countDict['false'] += 1
        return countDict

    def classifyTweet(self, tweet):
        """
        Classifies the tweet against the number of capital case words
        :param tweet: A string of text
        :return: A number between 0 and 1 when any word contains a capital case. None if there are no capital letters used.
        """
        wordCount = 0
        capCount = 0
        for word in tweet.split(' '):
            if len(word) != 0:
                if word[0] != "@" and word[0] != "#" and word[0] != "\'":
                    if word[:4] != "http":
                        if word[0].isdigit() == False:
                            wordCount += 1
                            if word[0].isupper():
                                capCount += 1
        if wordCount != 0:
            return 1 - (capCount / wordCount)
        return None


    def dumpFilter(self):
        return dict()

    def loadFilter(self, savedFilter):
        return None
