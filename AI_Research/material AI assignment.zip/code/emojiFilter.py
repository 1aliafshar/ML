import emoji
import re
from algorithms.filter.baseFilter import baseFilter


class emojiFilter(baseFilter):
    """
    This class implements an emoji-based filter, used for classifying texts.
    """

    def __init__(self):
        self.emoji_pattern = re.compile(r"\:[\w\_]+\:")
        self.emoji_dict = dict()  # emoji - fake % - real %

    def has_emoji(self, s):
        """
        This function returns true or false depending on whether the tweet has an emoji. If true, a list with all emoji's
        is returned
        :param s: String of text to scan
        :return: True or false. If True: List of emoji's
        """
        string = emoji.demojize(s)
        emoji_list = self.emoji_pattern.findall(string)

        if len(emoji_list) > 0:
            return True, emoji_list
        else:
            return False

    def train(self, trainingset):
        """
        Trains the filter to find whether each emoji is used more in real tweets or in fake tweets
        :param trainingset: Set of training texts
        :return: None.
        """
        emojiDict = dict()
        for tweet, value in trainingset.items():
            emojis = self.has_emoji(value['text'])
            if emojis:
                if value['label'] == '0':  # fake
                    for emojiItem in emojis[1]:
                        if emojiItem in emojiDict:
                            emojiDict[emojiItem][0] += 1
                        else:
                            emojiDict[emojiItem] = [0, 0]
                            emojiDict[emojiItem][0] = 1
                if value['label'] == '1':  # real
                    for emojiItem in emojis[1]:
                        if emojiItem in emojiDict:
                            emojiDict[emojiItem][1] += 1
                        else:
                            emojiDict[emojiItem] = [0, 0]
                            emojiDict[emojiItem][1] = 1

        for item, value in emojiDict.items():
            n = 100 / (value[0] + value[1])
            self.emoji_dict[item] = [(value[0] * n), (value[1] * n)]

    def classifyTweet(self, tweet):
        """
        Returns % chance it is a fake or real tweet ( all emoji's percentages / # emojis )
        :param tweet: String of text
        :return: Percentage of fakeness, or None if no tweets were found.
        """
        data = self.has_emoji(tweet)
        percentage = [0, 0]
        if data:
            for emoji in data[1]:
                if emoji in self.emoji_dict:
                    percentage[0] += self.emoji_dict[emoji][0]
                    percentage[1] += self.emoji_dict[emoji][1]
            percentage[0] = percentage[0] / len(data[1])
            percentage[1] = percentage[1] / len(data[1])

        if sum(percentage) == 0:
            return None
        return percentage[0]


    def dumpFilter(self):
        return self.emoji_dict

    def loadFilter(self, savedFilter):
        self.emoji_dict = savedFilter
        return None
