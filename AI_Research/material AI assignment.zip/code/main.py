import os

from algorithms.filter.algorithm import algorithm
from algorithms.tweetloader import getTweetDictTrain

def getFilterAlgorithm():
    """
    Finds a loaded algorithm. If no trained save is found, it will train again, and save it.
    :return: loaded and trained algorithm
    """
    a = algorithm()
    if a.loadFromFile("algorithms/trained/80w_20c"):
        return a
    else:
        # Initialise the algorithms, and train it.
        a = algorithm({"word": 0.8, "capital": 0.2})  # , "emoji": 0.1
        tweets = getTweetDictTrain("algorithms/tweets_labeled.csv")
        tweetList = list(tweets.items())
        trainListSplice = int((len(tweetList) / 5) * 4)
        trainTweets = dict(tweetList[:trainListSplice])
        validationTweets = dict(tweetList[trainListSplice:])
        a.trainFilters(trainTweets)
        a.saveAlgorithm("algorithms/trained/80w_20c")
        return a
