import csv
import re

def getTweetDictTrain(filename):
    """
    Loads the given filename and extracts the content into a double dictionary: [id]: {[text]:"text", [label]:0}
    :param filename:
    :return:
    """
    with open(filename, encoding="UTF-8") as csvfile:
        tweetDict = dict()
        tweetreader = csv.reader(csvfile, delimiter=',')
        next(tweetreader)

        for tweet in tweetreader:
            text = tweet[1].rstrip('...')
            text = text.strip('\'')
            #Retweets
            text = re.sub(r"RT\ \@\w*\:\ ", '', text)

            #Twitter compressed urls
            text = re.sub(r"https://t.co/\w*", '', text)

            tweetDict[tweet[0]] = {"text":text, "label":tweet[2]}

        return tweetDict

def getTweetDictTest(filename):
    """
    Loads the given filename and extracts the content into a double dictionary: [id]: {[text]:"text"}
    :param filename:
    :return:
    """
    with open(filename, encoding="UTF-8") as csvfile:
        tweetDict = dict()
        tweetreader = csv.reader(csvfile, delimiter=',')
        next(tweetreader)

        for tweet in tweetreader:
            text = tweet[1].rstrip('...')
            text = text.strip('\'')
            #Retweets
            text = re.sub(r"RT\ \@\w*\:\ ", '', text)

            #Twitter compressed urls
            text = re.sub(r"https://t.co/\w*", '', text)

            tweetDict[tweet[0]] = text

        return tweetDict


def getRatio(filename):
    """
    Returns a dictionary with the two labels and their total tweets
    :param filename:
    :return:
    """
    with open(filename, encoding="UTF-8") as csvfile:
        tweetreader = csv.reader(csvfile, delimiter=',')
        next(tweetreader)
        fakevstrueDict = {'0':0, '1':0}
        for tweet in tweetreader:
            fakevstrueDict[tweet[2]] += 1
        return fakevstrueDict

def getRatioFromTweets(tweets):
    fakevstrueDict = {'0':0, '1':0}
    for tweetid, value in tweets.items():
        fakevstrueDict[value['label']] += 1
    return fakevstrueDict
